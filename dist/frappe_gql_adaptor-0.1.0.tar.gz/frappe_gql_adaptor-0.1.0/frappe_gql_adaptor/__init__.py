__version__ = "0.1.0"

from frappe_gql_adaptor.api import graphql_server